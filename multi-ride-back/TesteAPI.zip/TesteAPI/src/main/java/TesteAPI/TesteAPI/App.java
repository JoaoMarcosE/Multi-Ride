package TesteAPI.TesteAPI;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;

import com.google.api.client.auth.oauth2.Credential;
import com.uber.sdk.core.auth.OAuth2Credentials;
import com.uber.sdk.core.auth.Scope;
import com.uber.sdk.core.client.CredentialsSession;
import com.uber.sdk.core.client.SessionConfiguration;
import com.uber.sdk.rides.client.UberRidesApi;
import com.uber.sdk.rides.client.model.Product;
import com.uber.sdk.rides.client.model.ProductsResponse;
import com.uber.sdk.rides.client.model.TimeEstimatesResponse;
import com.uber.sdk.rides.client.services.RidesService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		SessionConfiguration config = new SessionConfiguration.Builder()
		.setClientId("bKXPDCxo9uMV1_ZUo5OYcUztdFbJ1byC")
		.setClientSecret("xdViKYiRkwrRw0Xlfe3_VLlV3mvvDjGTQfdB6W14")
		.setScopes(Arrays.asList(Scope.PROFILE, Scope.REQUEST))
		.setRedirectUri("http://localhost")
		.build();

		OAuth2Credentials credentials = new OAuth2Credentials.Builder()
		.setSessionConfiguration(config)
		.build();

		try {
			String authorizationUrl = credentials.getAuthorizationUrl();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		String authorizationCode = "crd.EA.CAESEEhzx2FWu09Noxd8TrJQtaAiATE.qlTuPqXkRDW8eP0tC1buNa1Qo2Y7r_DbRGV1iLihsZY#_";
		String userId = "bKXPDCxo9uMV1_ZUo5OYcUztdFbJ1byC";
		Credential credential = credentials.authenticate(authorizationCode, userId);

		CredentialsSession session = new CredentialsSession(config, credential);

		RidesService service = UberRidesApi.with(session).build().createService();
		
		retrofit2.Response<ProductsResponse> response;
		try {
			response = service.getProducts(37.79f, -122.39f).execute();
			
			List<Product> body = (List<Product>) response.body();
			List<Product> products = body;
			String productId = products.get(0).getProductId();
			
			retrofit2.Response<TimeEstimatesResponse> timeResponse = service.getPickupTimeEstimate(37.79f, -122.39f, productId).execute();
			
			String time = timeResponse.body().toString();
			
			System.out.println(time);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    }
}
