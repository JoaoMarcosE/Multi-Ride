import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import javax.xml.ws.Response;

import com.uber.sdk.core.auth.Scope;
import com.uber.sdk.rides.auth.OAuth2Credentials;
import com.uber.sdk.rides.client.*;
import com.uber.sdk.rides.client.internal.*;
import com.uber.sdk.rides.auth.*;
import com.uber.sdk.rides.client.model.*;
import com.uber.sdk.rides.client.services.*;
import com.uber.sdk.rides.client.utils.*;
import com.uber.sdk.rides.client.CredentialsSession;
import com.uber.sdk.rides.client.SessionConfiguration;
import com.uber.sdk.rides.client.SessionConfiguration.Environment;
import com.uber.sdk.rides.client.UberRidesApi;
import com.uber.sdk.rides.client.services.RidesService;

public class Teste 
{
	public static void main(String[] args) 
	{
		SessionConfiguration config = new SessionConfiguration.Builder()
			    .setClientId("bKXPDCxo9uMV1_ZUo5OYcUztdFbJ1byC")
			    .setClientSecret("xdViKYiRkwrRw0Xlfe3_VLlV3mvvDjGTQfdB6W14")
			    .setEnvironment(Environment.SANDBOX)
			    .setScopes(Arrays.asList(Scope.PROFILE, Scope.REQUEST))
			    .setRedirectUri("http://localhost")
			    .build();

			OAuth2Credentials credentials = new OAuth2Credentials.Builder()
			    .setSessionConfiguration(config)
			    .build();

			try 
			{
				String authorizationUrl = credentials.getAuthorizationUrl();
			} 
			catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			}
			
			String authorizationCode;
			String userId; 
			
			Credential credential = credentials.authenticate(authorizationCode, userId);
			CredentialsSession session = new CredentialsSession(config, credential);
			RidesService service = UberRidesApi.with(session).createService();
			
			Response<List<Product>> response = service.getProducts(37.79f, -122.39f).execute();
			List<Product> products = response.body();
			String productId = products.get(0).getProductId();
			
			Response<TimeEstimatesResponse> response = service.getPickupTimeEstimate(37.79f, -122.39f, productId).execute();
	}

}
